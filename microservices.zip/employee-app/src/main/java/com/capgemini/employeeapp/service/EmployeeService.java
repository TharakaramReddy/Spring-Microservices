package com.capgemini.employeeapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.employeeapp.model.Employee;

@Service
public interface EmployeeService {

	public Employee addNewEmployee(Employee employee);
	public Employee findEmployeeById(int employeeId) throws Exception;
	public List<Employee> findAllEmployees();
} 
 
