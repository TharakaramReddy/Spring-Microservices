package com.capgemini.employeeapp.model;

import javax.persistence.Entity;

import javax.persistence.Entity;  
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int emplyeeId;
	private String employeeDepartment;
	private String employeeName;
	private double employeeSalary;

	public int getEmplyeeId() {
		return emplyeeId;
	}

	public void setEmplyeeId(int emplyeeId) {
		this.emplyeeId = emplyeeId;
	}

	public String getEmployeeDepartment() {
		return employeeDepartment;
	}

	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public Employee(int emplyeeId, String employeeDepartment, String employeeName, double employeeSalary) {
		super();
		this.emplyeeId = emplyeeId;
		this.employeeDepartment = employeeDepartment;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}

	public Employee() {
		super();
	}

} 
 
