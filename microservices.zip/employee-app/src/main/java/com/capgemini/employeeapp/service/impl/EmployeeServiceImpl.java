package com.capgemini.employeeapp.service.impl;

import com.capgemini.employeeapp.service.EmployeeService;

import java.util.List;  
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.employeeapp.exception.EmployeeNotFoundException;
import com.capgemini.employeeapp.model.Employee;
import com.capgemini.employeeapp.repository.EmployeeRepository;
import com.capgemini.employeeapp.service.EmployeeService;

@Repository
public class EmployeeServiceImpl implements EmployeeService {


	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Employee addNewEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee findEmployeeById(int employeeId) throws Exception {
	
		Optional<Employee> data=employeeRepository.findById(employeeId);
		if(data.isPresent())
		return data.get();
		throw new EmployeeNotFoundException("Employee Id not Found");
	}

	@Override
	public List<Employee> findAllEmployees() {
		return null;
	}

} 
 
